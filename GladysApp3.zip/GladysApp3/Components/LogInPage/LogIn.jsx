import React from "react";

import {
  SafeAreaView,
  Image,
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  TouchableOpacity,
} from "react-native";




export default function LogIn({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.jobizz}>Jobizz</Text>
      <Text style={styles.welcome}>
        Welcome Back{" "}
        <Image source={"./assets/hand.png"} style={{ height: 15, width: 15 }} />
      </Text>

      <Text style={{ color: "#AFB0B6", margin: 10 }}>
        Let's log in. Apply to jobs!
      </Text>
      <TextInput placeholder=" Name" style={styles.userName}></TextInput>
      <TextInput placeholder=" Email" style={styles.mail}></TextInput>
      <View style={{ margin: 10 }}>
        <Button
          title="Log In"
          onPress={() => navigation.navigate("Homepage")}
        ></Button>
      </View>

      <View
        style={{
          flexDirection: "row",
          justifyContent: "center",
          marginTop: 120,
        }}
      >
        <Text style={{ color: "#AFB0B6" }}>
          _____________________________________
        </Text>
        <Text style={{ color: "#AFB0B6" }}> or continue with </Text>
        <Text style={{ color: "#AFB0B6" }}>
          _____________________________________
        </Text>
      </View>

      <View style={styles.iconRow}>
        <Image source={"./assets/Group 56.png"} style={styles.images} />
        <Image
          source={"./assets/flat-color-icons_google.png"}
          style={{ marginTop: 51, width: 29, height: 29 }}
        />
        <Image source={"./assets/Group 54.png"} style={styles.images} />
      </View>

      <Text style={{ marginTop: 30, textAlign: "center" }}>
        Haven't an account?
        <TouchableOpacity>
          <Text style={{ color: "#356899" }}> Register</Text>
        </TouchableOpacity>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  jobizz: {
    color: "#356899",
    fontSize: 15,
    fontWeight: "bold",
    marginTop: 25,
    margin: 10,
  },
  welcome: {
    fontSize: 20,
    fontWeight: "bold",
    margin: 10,
  },
  userName: {
    marginTop: 50,
    margin: 10,
    color: "#AFB0B6",
    fontSize: 15,
    padding: 10,
    borderRadius: 5,
    
  },
  mail: {
    margin: 10,
    marginTop: 10,
    marginBottom: 50,
    color: "#AFB0B6",
    fontSize: 15,
    padding: 10,
    borderRadius: 5,
  },
  images: {
    marginTop: 20,
    width: 100,
    height: 100,
  },
  iconRow: {
    flexDirection: "row",
    justifyContent: "space-between", // Ensures even distribution
    marginTop: 20,
    marginHorizontal: 160,
  },
});
