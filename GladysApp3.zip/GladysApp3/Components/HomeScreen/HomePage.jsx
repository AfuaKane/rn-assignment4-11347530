import React from "react";
import {
  inputText,
  StyleSheet,
  Text,
  Image,
  SafeAreaView,
  TextInput,
} from "react-native";
newApp/assets/grommet-icons_google.png
export default function HomePage() {
  return (
    <SafeAreaView style={styles.area}>
      <Text style={styles.userName}>
        Eric Atsu{" "}
        <Image
          source={"./assets/Ellipse.png"}
          style={{ height: 30, width: 30 }}
        />
      </Text>
      <Text style={styles.userMail}>eric@gmail.com </Text>
      <TextInput placeholder="Search a job or position" style={styles.searchBar}/>
      <Text style={{fontSize: 18, fontWeight: "bold", marginTop: 30 }}>Featured Jobs
        <Text style={{fontSize: 15,marginEnd:100}}>See all</Text>
      </Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  area: {
    marginStart: 20,
    marginTop: 30,
  },

  userName: {
    fontSize: 25,
    fontWeight: "bold",
  },

  userMail: {
    color: "#AFB0B6",
    fontSize: 20,
  },

  searchBar:{
    marginTop: 30,
    fontSize: 20,
    padding: 15
  }
});
