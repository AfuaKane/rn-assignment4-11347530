import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Image } from "react-native";
import LogIn from "./Components/LogInPage/LogIn";
import HomePage from "./Components/HomeScreen/HomePage";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <stack.Navigator initialRouteName="Log in">
        <stack.Screen name="Log in" component={LogIn} />
        <stack.Screen name="Homepage" component={HomePage} />
      </stack.Navigator>
    </NavigationContainer>
  );
}
